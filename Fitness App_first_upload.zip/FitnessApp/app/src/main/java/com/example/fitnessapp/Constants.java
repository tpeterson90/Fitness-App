package com.example.fitnessapp;

public class Constants {
    public static final String KEY_COLLECTION_USERS = "users";
    public static final String KEY_FIRST_NAME = "firstName";
    public static final String KEY_LAST_NAME = "lastName";
    public static final String KEY_EMAIL = "email";
    public static final String KEY_PASSWORD = "password";
    public static final String KEY_USER_ID = "user_id";
    public static final String KEY_IS_SIGNED_IN = "isSignedIn";

    public static final String KEY_PREFERENCE_NAME = "chatAppPreference";
    public static final String KEY_IMAGE = "image";
}
