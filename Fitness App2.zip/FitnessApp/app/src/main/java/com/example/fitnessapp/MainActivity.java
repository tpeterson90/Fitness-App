package com.example.fitnessapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    DrawerLayout drawerLayout;
    NavigationView navigationView;
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_menu);

        /*--------------------Hooks--------------------*/
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        toolbar = findViewById(R.id.toolbar);

        /*-------------------Tool Bar-------------------*/
        setSupportActionBar(toolbar);

        /*-------------------Navigation Drawer-------------------*/
        // Hide or Show items in menu
        Menu menu = navigationView.getMenu();
        menu.findItem(R.id.nav_login).setVisible(false); // hiding login


        navigationView.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setCheckedItem(R.id.nav_session);

        getOnBackPressedDispatcher().addCallback(this, new androidx.activity.OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    drawerLayout.closeDrawer(GravityCompat.START);
                } else {
                    finish();
                }
            }
        });
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        drawerLayout.closeDrawer(GravityCompat.START);

        drawerLayout.post(() -> {
            // if Main activity is home, do nothing
            if (id == R.id.nav_session) {
                startActivity(new Intent(MainActivity.this, Session_Activity.class));
            }else if (id == R.id.nav_dashboard) {
                startActivity(new Intent(MainActivity.this, DashBoard.class));
            }else if (id == R.id.nav_analysis) {
                startActivity(new Intent(MainActivity.this, Analysis.class));
            }else if (id == R.id.nav_settings) {
                startActivity(new Intent(MainActivity.this, Settings.class));
            }else if (id == R.id.nav_login) {
                startActivity(new Intent(MainActivity.this, SignInActivity.class));
            }else if (id == R.id.nav_share) {
                Toast.makeText(MainActivity.this, "Share", Toast.LENGTH_SHORT).show();
            }else if (id == R.id.nav_rate) {
                Toast.makeText(MainActivity.this, "Rate", Toast.LENGTH_SHORT).show();
            }else if (id == R.id.nav_logout) {
                startActivity(new Intent(MainActivity.this, SignInActivity.class));
            }else{
                Toast.makeText(MainActivity.this, "Unhandled: " +
                        getResources().getResourceEntryName(id), Toast.LENGTH_SHORT).show();
            }
        });
        return true;
    }
}
